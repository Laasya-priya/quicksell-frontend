import React, { useState, useEffect } from "react";
import GroupSelector from "./GroupSelector";
import SortSelector from "./SortSelector";
import TicketCard from "./TicketCard";
import "../styles/kanban.css";

const KanbanBoard = () => {
  const [tickets, setTickets] = useState([]);
  const [users, setUsers] = useState([]);
  const [grouping, setGrouping] = useState(localStorage.getItem("grouping") || "status");
  const [sorting, setSorting] = useState(localStorage.getItem("sorting") || "priority");
  const [error, setError] = useState(null);

  // Fetch tickets and users from API
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("https://api.quicksell.co/v1/internal/frontend-assignment");
        const data = await response.json();
        setTickets(data.tickets);
        setUsers(data.users);
      } catch (err) {
        console.error("Error fetching data:", err);
        setError("Failed to fetch data. Please try again later.");
      }
    };

    fetchData();
  }, []);

  // Persist grouping and sorting preferences
  useEffect(() => {
    localStorage.setItem("grouping", grouping);
    localStorage.setItem("sorting", sorting);
  }, [grouping, sorting]);

  // Group tickets based on the selected criteria
  const groupTickets = () => {
    if (!Array.isArray(tickets)) return {};

    return tickets.reduce((acc, ticket) => {
      let key;
      if (grouping === "status") {
        key = ticket.status;
      } else if (grouping === "user") {
        const user = users.find((user) => user.id === ticket.userId);
        key = user ? user.name : "Unassigned";
      } else if (grouping === "priority") {
        key = `Priority ${ticket.priority}`;
      } else {
        key = "Other";
      }

      acc[key] = acc[key] || [];
      acc[key].push(ticket);
      return acc;
    }, {});
  };

  // Sort tickets based on the selected sorting method
  const sortTickets = (tickets) => {
    return tickets.slice().sort((a, b) => {
      if (sorting === "priority") {
        return b.priority - a.priority;
      } else if (sorting === "title") {
        return a.title.localeCompare(b.title);
      }
      return 0;
    });
  };

  // Group and sort tickets
  const groupedTickets = groupTickets();

  // Loading or error state
  if (error) {
    return <p className="error-message">{error}</p>;
  }

  if (tickets.length === 0 || users.length === 0) {
    return <p className="loading-message">Loading tickets...</p>;
  }

  return (
    <div className="kanban-board">
      <GroupSelector grouping={grouping} setGrouping={setGrouping} />
      <SortSelector sorting={sorting} setSorting={setSorting} />
      <div className="kanban-columns">
        {Object.keys(groupedTickets).map((group) => (
          <div key={group} className="kanban-column">
            <h3 className="kanban-column-title">{group}</h3>
            {sortTickets(groupedTickets[group]).map((ticket) => (
              <TicketCard key={ticket.id} ticket={ticket} users={users} />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default KanbanBoard;
